def multiply_list(_list):
    x = 1
    for i in range(len(_list)):
        x *= _list[i]
    return x
